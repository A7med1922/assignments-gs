//task1

num_one = 10;
num_two = 20;
console.log(num_one + "" + num_two);
console.log(typeof(num_one + "" + num_two));

console.log(`${num_one}${num_two}`);
console.log(typeof(`${num_two}${num_one}`));

console.log(num_two + "\n" + num_one);
console.log(`${num_two}
${num_one}`);



//task2

console.log(elzero.innerHTML); // object          //div has  id "elzero" in html
console.log(typeof elzero); // object

//task3

console.log("`I'm in \n \\\\\n love \\\\ \"\"\" \'\'\' \n++ with ++ \n \\\"\"\"\\ \"\"\" \n \"\" javascript\"\"`` ");

//task4

let a = 21;
let b = 20;
console.log(`_${a}_${b}${a}_${b}${a}_${b}${a}_${b}_`);
