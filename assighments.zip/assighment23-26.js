// task1

// Examples
console.log(100_000); // 100000
console.log(100000); // 100000
console.log(5e4 + 5e4); // 100000

// Your Solutions
console.log(1e5); // 100000
console.log(Math.ceil(Math.pow(316.227766,2))); // 100000
console.log(parseInt("100000")); // 100000
console.log(Math.trunc(parseFloat("100000.544"))); // 100000
console.log(500_00 *2); // 100000
console.log(Math.sqrt(100_000_000_00)); // 100000
console.log(Math.trunc(100_000.522555555555555555)); // 100000
console.log(Math.ceil(99999.5)); // 100000
console.log(Math.max(2,433,54, 100_000, 100_00)); // 100000
console.log(Math.floor(100_000.25554555)); // 100000



//task2
console.log(- Number.MIN_SAFE_INTEGER); // 9007199254740991


//task3
console.log(Number.MAX_SAFE_INTEGER.toString().length); // 16   بحولها ل سترينج الاول وبقوله عدلي الحروف ب لينجس
//or
console.log((Number.MAX_SAFE_INTEGER * false) + ("MAX_SAFE_INTEGER".toString().length));

//task4

let myVar = "100.56789 Views";

console.log(parseInt(myVar)); // 100
console.log(Number(parseFloat(myVar).toFixed(2))); // 100.57

// task5

let num = 10;

console.log((Number.isInteger(num)) + true); // 2

// task6

let flt = 10.4;

console.log(Math.floor(flt)); // 10
console.log(Math.round(flt)); // 10
console.log(Math.trunc(flt)); // 10
console.log(Number.parseInt(flt)); // 10
console.log(Number(flt.toFixed(0))); // 10


//task7

// to choose random num from 1 to 10 ==> we use    Math.ceil(Math.random()*10)      or        Math.floor(Math.random()*11) 

console.log(Math.ceil(Math.random()*4)); // 0 || 1 || 2 || 3 || 4