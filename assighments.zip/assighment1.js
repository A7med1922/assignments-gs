console.log("hello assighment1");


document.write("<h2>Elzero is saka</h2>");
document.querySelector('h2').style.color = "blue";
console.log("%cElzero %cWeb %cSchool", "color: red; font-size: 40px;", "color: green; font-size: 40px; font-weight: 900;", "color: white; font-size: 40px; background-color: blue;");



console.group("%c group 1", "color: blue; font-size:20px;");
console.log("%c message one", "color: red;");
console.log("message two");
    console.groupCollapsed("%c child group",'color: #bada55;');
    console.log("message one");
    console.log("message two");
        console.groupCollapsed("grand child group");
        console.log("message one");
        console.log("message two");
        console.groupEnd();
    console.groupEnd();
console.groupEnd();

console.group("%c group 2", "color: green; font-size:20px;");
console.log("message one");
console.log("message two");
console.groupEnd();

// console.group("%c group 1", 'background: #222; color: #bada55');
// console.log("%c message one",'color: #bada55');
// console.log("%c message two" ,'color: #bada55');
//     console.groupCollapsed("%c child group",'color: #bada55');
//     console.log("message one");
//     console.log("message two");
//         console.groupCollapsed("grand child group");
//         console.log("message one");
//         console.log("message two");
//         console.groupEnd();
//     console.groupEnd();
// console.groupEnd();

// console.group("%c group 2", 'background: orange; color: black');
// console.log("%c message one","color: orange");
// console.log("%c message two","color: orange");

/*
 هذه الطريقة تستخدم لتنسيق المخرجات وتجميعها عند التعامل مع consloe.group 

عند استخدام console.groupتقوم بفتح مجموعة جديدة ولكي تفصلها عن التي تليها عليك كتابة console.groupEnd(); 
بعدد مرات بداية المجموعات التي فتحتها لكي تبدأ بمجموعة جديدة ليست أبناء للأولى 
*/ 

console.table(["ahmed","saka", "xavi", "saka3", "Aya"]);

//console.log("Iam In Console");

/*
document.write("Iam In Page");
*/