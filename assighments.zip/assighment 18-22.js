// task 1
console.log((10 * 20) + (15 % 3) + (190 + 10) -  400);
           //  10* 20 -190 -10



//task 2
           let num = 3;

// Solution One
console.log(num +true +true +true); // 6

// Solution Two
// console.log(++num +true +true); // 6

// Soultion Three
// console.log(--num + ++num + true ); // 6

// Soultion Four
        //  3        2       1
// console.log(num-- + num-- + num-- ); // 6

// Solution Five
// console.log(num++ + num++ - true); // 6

// Solution Six
console.log(-- num+ num +num); // 6


// task 3
let num2 = "10";

// Solution One
console.log(+num2 + +num2); // 20

// Solution Two
// console.log(+num2++ + +num2 - true); // 20

// Solution Three
// console.log(+num2+ --num2 + true ); // 20

// Solution Four
console.log(+num2-- + --num2 + true + true ); // 20



// task 4
let points = 10;

points +=3;

console.log(points); // 13

points -=5;

console.log(points); // 8;