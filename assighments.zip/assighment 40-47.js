
//task1

let myFriends = ["Ahmed", "Elham", "Osama", "Gamal"];
let num = 3;

// Method 1
console.log(myFriends.slice(num-num,num)); // ["Ahmed", "Elham", "Osama"];

// Method 2
myFriends.length = num;
console.log(myFriends); // ["Ahmed", "Elham", "Osama"];

// // Method 3
// myFriends.pop();
// console.log(myFriends); // ["Ahmed", "Elham", "Osama"];

//task2

let friends = ["Ahmed", "Eman", "Osama", "Gamal"];

// Write Your Code Here

friends.shift();
friends.pop();
console.log(friends); // ["Eman", "Osama"]




//task3

let arrOne = ["C", "D", "X"];
let arrTwo = ["A", "B", "Z"];
let finalArr = [];

finalArr = arrOne.concat(arrTwo).sort().reverse();
console.log(finalArr); // ["Z", "X", "D", "C", "B", "A"]


//task4

let website = "Go";
let words = [`${website}ogle`, "Facebook", ["Elzero", "Web", "School"]];

console.log(words[website.length][website.length-website.length].slice(website.length).toUpperCase()); // ZERO


//task5

let needle = "JS";
let haystack = ["PHP", "JS", "Python"];

// Write 3 Solutions
if (haystack.includes(needle))
{
    console.log("found");
}
else
{
    console.log("not found");
}
haystack.includes(needle)===true ? console.log("found") :console.log("not found");

haystack[1]===needle ? console.log("found") :console.log("not found");

// console.log(haystack);
switch (haystack[1]=needle)
{
  case needle:
    console.log("found");
  break;
  default:
    console.log("not found");
}



//task6

let arr1 = ["A", "C", "X"];
let arr2 = ["D", "E", "F", "Y"];
let allArrs = [];

// Your Code Here
// allArrs = (arr2[arr1.length-true].concat(arr1[arr1.length-true],arr2[arr1.length])).toLowerCase();
// console.log(allArrs); // fxy

// //else
// allArrs = (arr2[Math.trunc((arr1.length*arr1.length)/(arr2.length))].concat(arr1[Math.trunc((arr1.length*arr1.length)/(arr2.length))],arr2[arr1.length])).toLowerCase();
// console.log(allArrs); // fxy



let ss = (allArrs.concat(arr1,arr2).sort());
let dd = ss.slice(arr2.length);
let saka2 = dd.join("").toLowerCase();
console.log(saka2.toLowerCase());