// task1


let userName = "Elzero";
console.log(userName[0].toLowerCase()); // e
console.log(userName.charAt(0).toLowerCase()); // e
console.log(userName.slice(0,1).toLowerCase()); // e
console.log(userName.substring(0,1).toLowerCase()); // e
console.log(userName.substr(0,1).toLowerCase()); // e
console.log(userName.slice(-3,-2).toLowerCase().repeat(3)); // eee



//task2

let word = "Elzero";
let letterZ = "z";
let letterE = "e";
let letterO = "O";

console.log(word.includes(letterZ));  // true
console.log(word.startsWith(letterE.toUpperCase())); // True
console.log(word.endsWith(letterO.toLowerCase())); // True


console.log(((word.substring(0,2))+(`${word.charAt(2).toUpperCase()}`)+(word.substr(-3))).endsWith("Z",3)); // True
console.log(word.startsWith("E")); // True
console.log(word.endsWith("o")); // True