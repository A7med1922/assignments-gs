let day = "                       wednesday            ";
// You Need To Remove Spaces And Make First Letter Capital => Friday

let day2 = "Friday";
let day3 = "Saturday";
let day4 = "Sunday";
// Output => "No Appointments Available"

let day5 = "Monday";
let day6 = "Thursday";
// Output => "From 10:00 AM To 5:00 PM"

let day7 = "Tuesday";
// Output => "From 10:00 AM To 6:00 PM"

let day8 = "Wednesday";
// Output => "From 10:00 AM To 7:00 PM"

let day9 = "World";
// Output => "Its Not A Valid Day"

switch(day.trim().charAt(0).toUpperCase()+day.trim().slice(1))
{
    case "Friday" :
    case "Saturday" :
    case "Sunday" :    
     console.log("No Appointments Available")
     break;
   
   case "Monday" :  
   case "Thursday" : 
    console.log("From 10:00 AM To 5:00 PM")
    break;
   
   case "Tuesday" : 
   console.log("From 10:00 AM To 6:00 PM")
   break;

   case "Wednesday" :
    console.log("From 10:00 AM To 7:00 PM")
    break;

    default : 
    console.log("Its Not A Valid Day")
}
console.log(day.trim().charAt(0).toUpperCase()+day.trim().slice(1,100));
