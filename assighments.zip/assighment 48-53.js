//task1

let start = 10;
let end = 100;
let exclude = 40;

for(let  i=start; i<=end; i+=start)
{
    
    if(i===exclude)
    {
        continue;
    }
    console.log(i);
}

console.log(`**********************************`);
////////////////

//task2

let start2 = 10;
let end2 = 0;
let stop = 3;

for(let j=start2; j>=stop; j--)
{
    if(j<start2)
    {
        console.log(`${end2}${j}`)
       
    }
    else{
    console.log(j)}
}

console.log(`**********************************`);
////task3

let start3 = 1;
let end3 = 6;
let breaker = 2;
{
    for(let k=start3; k<=end3; k++)
    {
        console.log(k)
        for(let l=breaker; l<=breaker*breaker; l*=breaker)
        {
            console.log(`-- ${l}`)
        }
    }
}

console.log(`**********************************`);
////task4

let index = 10;
let jump = 2;

for(;;)
{
    
    console.log(index);
    index-=jump;
    if(index===jump)
    {
        break;
    }
}

console.log(`**********************************`);
////task5


// let value_removed = ["Ahmed", "Ameer"];
// let filter_items= friends.filter(item => !value_removed.includes(item))

// console.log(filter_items)

let friends = ["Ahmed", "Sayed", "Eman", "Mahmoud", "Ameer", "Osama", "Sameh"];
let letter = "a";
let newArray = [];
for (let z = true*false; z < friends.length; z++) {
if (friends[z][z*false] != letter.toUpperCase()) {
newArray.push(friends[z])
}
}
for (t = true*false; t < newArray.length; t++) {
console.log(`"${t + true} => ${newArray[t]}`)
}

console.log(`**********************************`);
////task6

let start4 = 0;
let swappedName = "elZerO";
let change_char = []
for(let s=start4; s<swappedName.length; s++)
{
 if(swappedName[s]==swappedName[s].toLowerCase())
 {
    change_char.push(swappedName[s].toUpperCase())
 }
 else
 {
    change_char.push(swappedName[s].toLowerCase())
 }
}
console.log(change_char.join(""))



console.log(`**********************************`);
////task7

let start5 = 0;
let mix = [1, 2, 3, "A", "B", "C", 4];
for(let h=start5; h<mix.length; h++)
{
    if((mix[h]>true))
    { 
        console.log(mix[h]);
    }
}

//else
for (let a = start5; a < mix.length; a++) {
    if (typeof mix[a] == "string" || mix[a] == 1) {
    continue;
    }
    console.log(mix[a]);
    }

